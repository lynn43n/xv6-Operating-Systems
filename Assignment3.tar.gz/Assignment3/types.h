typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  uchar;
typedef uint pde_t;

#define MAX_PYSC_PAGES  16
#define MAX_TOTAL_PAGES 32